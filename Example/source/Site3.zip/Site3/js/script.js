(function($){$(function(){



})})(jQuery)